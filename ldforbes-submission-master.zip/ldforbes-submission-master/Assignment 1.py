import types

#TBC - 3.3, 3.4, 3.7, 3.8

# Problem 3.1
print("Problem 3.1 Answer:")
def fib(x):
   if x <= 1:
       return x
   else:
       return fib(x-1) + fib(x-2)

for i in range(20):
   print(fib(i))


#Problem 3.2
def firstLast(seq):
   first = seq[0]
   last = seq[len(seq) - 1]
   if len(seq) == 1:
       newTup = (first)
       return newTup
   else:
       newTup = (first, last)
       return newTup
   return "Didn't work"
print("Problem 3.2 Answer:")
print(firstLast([5,10,15]))


#Problem 3.3
class  node:
   def  __init__(self , value , subnodes ):
       self.value = value
       self.subnodes = subnodes
extree = node(1,[node (2,[]), node(3,[node(4,[node(5,[]), node(6,[node (7 ,[])])])])])

def sumNodesRec(root):
    sum = 0
    for subNode in root.subnodes:
        sum = sum + sumNodesRec(subNode)
    return sum + root.value
print("Problem 3.3 Answer:")
print(sumNodesRec(extree))

#Problem 3.4
#Complete thesumNodesNoRec(root)function so it returns the sumof the values at each 
#node in the tree without using recursion.
def sumNodesNoRec(root):
    sum = 0
    nodeQueue = [root]
    while nodeQueue:
        current = nodeQueue.pop(0)
        nodeQueue.extend(current.subnodes)
        sum = sum + current.value
        # numChildren = len(current.subnodes)
        # if numChildren == 2:
        #     nodeQueue.extend(current.subnodes(0))
        #     nodeQueue.extend(current.subnodes(1))
        #     sum = sum + current.value
        # elif numChildren == 1:
        #     nodeQueue.extend(current.subnodes(0))
        #     sum = sum + current.value
        # else:
        #     return sum + current
    return sum
print("Problem 3.4 Answer:")
print(sumNodesNoRec(extree))

#Problem 3.5 
compose = lambda x: lambda y: lambda z: x * y * z
f_inner = compose(2) #Doubles amount
f_outer  = f_inner(.5)  #Split amount in half
print("Problem 3.5 Answer:")
print(f_outer(8)) #Should be 4 because multiply by .5


#Problem 3.6
# complete  thetwice(iterable)function,  which  takes  any  iter-able 
# (like a list, generator, or any data structure you can iterate through) 
# andy yields each element of the iterable twice.  
# Your implementation should utilize the yield keyword.

def yieldFunction(x):
    yield(x)

def twice(iterable):
    if(isinstance(iterable, types.GeneratorType)):
        for i in iterable:
            print(i)
            myYield = yieldFunction(i)
            for i in myYield:
                print(i)
    else:
        size = len(iterable)
        for i in range(size):
            print(iterable[i])
            myYield2 = yieldFunction(iterable[i])
            for i in myYield2:
                print(i)
        
print(twice([1,2,3]))
gen = (x for x in range(3))
print("Problem 3.6 Answer:")
print(twice(gen))

#Problem 3.7
# Your implementationshould utilize try/except statements and theyieldkeyword.

def valid(iterable, function):
    for i in iterable:
        try:
            myYield3 = yieldFunction(function(i))
            for i in myYield3:
                if i is not None:
                    print(i)
        except ValueError:
            print("Hex value can't be determined")
    return


def  toHex(value , minbytes=0, maxbytes =-1):
    if type(value) != int:
        raise  ValueError('Integer  expected.')
    hexValues =  '0123456789abcdef'
    hexString = ''
    while (value or  minbytes  > 0) and  maxbytes  != 0:
            hexString = hexValues[value % 16] + hexString
            value  //= 16
            minbytes  -= .5
            maxbytes  -= .5
    return  hexString
print("Problem 3.7 Answer:")
print(valid([255, 16, 'foo', 3], toHex))

#Problem 3.8

def treeToString(root):
    s = ""
    # nQueue = [root]
    # while nQueue:
    #     current = nQueue.pop(0)
    #     s = s + str(current.value)

    #     numChildren = len(current.subnodes)
    #     if(numChildren == 2):
    #         s = s + "\n"
    #         lChild = nQueue.pop(0)
    #         s = s + str(lChild.value)
    #         rChild = nQueue.pop(0)
    #         s = s + str(rChild.value)
    #     elif(numChildren == 1):
    #         s = s + "\n"
    #         onlyChild = nQueue.pop(0)
    #         s = s + str(onlyChild.value)
    #     else:
    #         return s
    sum = 0
    numChildren = len(root.subnodes)
    for subNode in root.subnodes:
        if(numChildren == 2):
            s = s + "\n"
            lChild = nQueue.pop(0)
            s = s + str(lChild.value)
            rChild = nQueue.pop(0)
            s = s + str(rChild.value)
        elif(numChildren == 1):
            s = s + "\n"
            onlyChild = nQueue.pop(0)
            s = s + str(onlyChild.value)
        else:
            return s
        sum = sum + sumNodesRec(subNode)
    return sum + root.value
print(treeToString(extree))

